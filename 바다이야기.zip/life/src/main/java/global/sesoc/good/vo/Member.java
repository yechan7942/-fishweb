package global.sesoc.good.vo;

import lombok.Data;

@Data
public class Member {


	String id;
	String password;
	String name;
	String phone;
	String email;

	
}
