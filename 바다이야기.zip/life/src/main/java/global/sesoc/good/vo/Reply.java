package global.sesoc.good.vo;

import lombok.Data;

@Data
public class Reply {

	int num;
	String name;
	String text;

}
